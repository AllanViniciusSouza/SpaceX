﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777217
	objId: 16777217
	x: 0
	y: 0
	width: 480
	height: 272
	IGuiTextField
	{
		id: q268435465
		objId: 268435465
		x: 13
		y: 52
		width: 140
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554437
		objId: 33554437
		x: 152
		y: 50
		width: 45
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiTextField
	{
		id: q268435466
		objId: 268435466
		x: 205
		y: 52
		width: 16
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435467
		objId: 268435467
		x: 237
		y: 52
		width: 140
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554438
		objId: 33554438
		x: 376
		y: 50
		width: 45
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiTextField
	{
		id: q268435468
		objId: 268435468
		x: 429
		y: 52
		width: 17
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435469
		objId: 268435469
		x: 120
		y: 50
		width: 16
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435470
		objId: 268435470
		x: 13
		y: 84
		width: 32
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435471
		objId: 268435471
		x: 13
		y: 116
		width: 58
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435472
		objId: 268435472
		x: 13
		y: 148
		width: 39
		height: 23
		qm_Transparent : true 
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554439
		objId: 33554439
		x: 83
		y: 84
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554440
		objId: 33554440
		x: 123
		y: 84
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554441
		objId: 33554441
		x: 163
		y: 84
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554442
		objId: 33554442
		x: 203
		y: 84
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554443
		objId: 33554443
		x: 83
		y: 116
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554444
		objId: 33554444
		x: 123
		y: 116
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554445
		objId: 33554445
		x: 163
		y: 116
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554446
		objId: 33554446
		x: 203
		y: 116
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554447
		objId: 33554447
		x: 83
		y: 148
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554448
		objId: 33554448
		x: 123
		y: 148
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554449
		objId: 33554449
		x: 163
		y: 148
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiIOField
	{
		id: q33554450
		objId: 33554450
		x: 203
		y: 148
		width: 36
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff424952"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff31344a"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
	}
	IGuiButton
	{
		id: q486539290
		objId: 486539290
		x: 268
		y: 116
		width: 70
		height: 35
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/21#2#4#128#0#0"
		qm_Border.top: 5
		qm_Border.bottom: 5
		qm_Border.right: 5
		qm_Border.left: 5
		qm_FillColor: "#ffffcf00"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
		qm_FocusWidth: 2
		qm_FocusColor: "#ff94b6e7"
	}
}
