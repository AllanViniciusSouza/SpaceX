﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777218
	objId: 16777218
	x: 0
	y: 0
	width: 480
	height: 272
	IGuiAlarmView
	{
		id: q402653184
		objId: 402653184
		x: 6
		y: 42
		width: 468
		height: 180
		qm_BorderCornerRadius: 4
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff6b717b"
		qm_FillColor: "#fff7f3f7"
		IGuiListCtrl
		{
			id: qu402653184
			objectName: "qu402653184"
			x: 2
			y: 2
			width: 464
			height: 166
			totalColumnWidth: 439
			qm_leftImageID: 24
			qm_leftTileTop: 4
			qm_leftTileBottom: 14
			qm_leftTileRight: 2
			qm_leftTileLeft: 4
			qm_middleImageID: 25
			qm_middleTileTop: 2
			qm_middleTileBottom: 15
			qm_middleTileRight: 2
			qm_middleTileLeft: 2
			qm_rightImageID: 26
			qm_rightTileTop: 4
			qm_rightTileBottom: 14
			qm_rightTileRight: 4
			qm_rightTileLeft: 2
			qm_leftBorderCornerRadius: 2
			qm_tableBackColor: "#ffffffff"
			qm_tableSelectBackColor: "#ff94b6e7"
			qm_tableAlternateBackColor: "#ffe7e7ef"
			qm_tableHeaderBackColor: "#ff84868c"
			qm_tableTextColor: "#ff181c31"
			qm_tableSelectTextColor: "#ffffffff"
			qm_tableAlternateTextColor: "#ff181c31"
			qm_tableMarginLeft: 2
			qm_tableMarginRight: 1
			qm_tableMarginBottom: 1
			qm_tableMarginTop: 1
			qm_tableHeaderTextColor: "#ffffffff"
			qm_tableHeaderValueVarTextAlignmentHorizontal: Text.AlignLeft
			qm_tableHeaderValueVarTextAlignmentVertical: Text.AlignVCenter
			qm_tableHeaderMarginLeft: 3
			qm_tableHeaderMarginRight: 1
			qm_tableHeaderMarginBottom: 1
			qm_tableHeaderMarginTop: 1
			qm_gridLineStyle: 0
			qm_gridLineWidth: 0
			qm_gridLineColor: "#ffffffff"
			qm_noOfColumns: 4
			qm_tableRowHeight: 16
			qm_tableHeaderHeight: 16
			qm_hasHeader: true
			qm_hasGridLines: false
			qm_hasBorder: false
			qm_hasDisplayFocusLine: true
			qm_hasVerticalScrolling: true
			qm_hasVerticalScrollBar: true
			qm_hasHorizontalScrollBar: false
			qm_hasColumnOrdering: false
			qm_hasHighLightFullRow: true
			qm_hasVerUpDownPresent: false
			qm_hasVerPgUpDownPresent: false
			qm_hasHighlight: true
			qm_hasUpDownAsPageUpDown: false
			qm_hasLongAlarmButton: true
			qm_hasExtraPixelForLineHeight: false
			qm_hasRowEditable: false
			qm_hasRowJustification: false
			qm_hasRowJustificationBottom: false
			qm_linesPerRow: 1
			qm_scrollCtrl: qus402653184

			IGuiListColumnView
			{
				id: qc118000000
				colIndex: 0
				x: 0
				y: 0
				width: 60
				height: 134
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiListColumnView
			{
				id: qc218000000
				colIndex: 1
				x: 60
				y: 0
				width: 86
				height: 134
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiListColumnView
			{
				id: qc318000000
				colIndex: 2
				x: 146
				y: 0
				width: 78
				height: 134
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiListColumnView
			{
				id: qc418000000
				colIndex: 3
				x: 224
				y: 0
				width: 215
				height: 134
				columnType: 0
				qm_columnValueVarTextAlignmentHorizontal: Text.AlignLeft
				qm_columnValueVarTextAlignmentVertical: Text.AlignVCenter
			}
			IGuiScrollBarCtrl
			{
				id: qus402653184

			}
		}
	}
}
